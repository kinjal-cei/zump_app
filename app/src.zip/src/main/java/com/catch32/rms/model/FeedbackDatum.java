package com.catch32.rms.model;

/**
 * @author Ruchi Mehta
 * @version Oct 16, 2019
 */
public class FeedbackDatum {

    private String CM_NAME;

    private String CM_NO;

    public String getCM_NAME() {
        return CM_NAME;
    }

    public void setCM_NAME(String CM_NAME) {
        this.CM_NAME = CM_NAME;
    }

    public String getCM_NO() {
        return CM_NO;
    }

    public void setCM_NO(String CM_NO) {
        this.CM_NO = CM_NO;
    }
}
