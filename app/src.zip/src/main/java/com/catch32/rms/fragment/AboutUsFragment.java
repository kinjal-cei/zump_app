package com.catch32.rms.fragment;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.catch32.rms.R;
import com.catch32.rms.activity.MainActivity;
import com.catch32.rms.activity.SignInActivity;
import com.catch32.rms.constant.AppConstant;
import com.catch32.rms.constant.BaseSharedPref;
import com.catch32.rms.dialog.ChangePasswordUpdateDialog;
import com.catch32.rms.factory.GsonFactory;
import com.catch32.rms.listener.ResponseListener;
import com.catch32.rms.model.Login;
import com.catch32.rms.model.Profile;
import com.catch32.rms.model.ProfileData;
import com.catch32.rms.network.PostDataToServerTask;
import com.catch32.rms.process.AppUserManager;
import com.catch32.rms.utils.IBaseMenuActivity;
import com.catch32.rms.utils.SharedPrefFactory;
import com.catch32.rms.utils.SharedPrefUtil;
import com.catch32.rms.utils.WidgetUtil;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

/**
 * @author Ruchi Mehta
 * @version Jun 14, 2019
 */
public class AboutUsFragment extends Fragment implements View.OnClickListener, ResponseListener {

    private static final String TAG = CallUsFragment.class.getSimpleName();
    private Context mContext;
    private TextView mNameTxt, mGenderTxt, mAddressTxt, mMobileTxt, mEmailTxt;
    private TextView mHeaderTxt, mBody1Txt, mBody2Txt, mBottomTxt, mBody3Txt;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_about_us, container, false);
        init(view);
        return view;
    }

    private void init(View view) {
        mContext = getActivity();
        view.findViewById(R.id.btn_change_password).setOnClickListener(this);
        view.findViewById(R.id.btn_logout).setOnClickListener(this);

        mHeaderTxt = (TextView) view.findViewById(R.id.txt_header);
        mBottomTxt = (TextView) view.findViewById(R.id.txt_bottom);
        mBody3Txt = (TextView) view.findViewById(R.id.txt_body3);
        mBody1Txt = (TextView) view.findViewById(R.id.txt_body1);
        mBody2Txt = (TextView) view.findViewById(R.id.txt_body2);

        SharedPrefUtil sharedPref = SharedPrefFactory.getProfileSharedPreference(mContext);
        String userCd = sharedPref.getString(BaseSharedPref.USER_CD_KEY);
        String mobileNo = sharedPref.getString(BaseSharedPref.MOBILE_NUMBER_KEY);

        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("usercd", userCd);
        jsonObject.addProperty("mobileNo", mobileNo);


        new PostDataToServerTask(mContext, AppConstant.Actions.GET_PROFILE)
                .setPath(AppConstant.WebURL.GET_PROFILE)
                .setResponseListener(this)
                .setRequestParams(jsonObject)
                .makeCall();

    }

    private void initNavigationView() {
        if (getActivity() instanceof IBaseMenuActivity) {
            IBaseMenuActivity baseMenuActivity = (IBaseMenuActivity) getActivity();
            baseMenuActivity.setActionbarTitle("About Us");
            baseMenuActivity.checkMenuItem(R.id.call_us);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_change_password:
                ChangePasswordUpdateDialog dialog = new ChangePasswordUpdateDialog();
                dialog.show(getChildFragmentManager(), "Cancel");
                break;

            case R.id.btn_logout:
                AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                builder.setIcon(R.drawable.ic_logout_red_48dp);
                builder.setTitle("Privacy Policy");
                builder.setMessage("I Agree ?");
                builder.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        AppUserManager.logout(mContext, SignInActivity.class);
                    }
                });
                builder.setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });

                AlertDialog alertDialog = builder.create();
                alertDialog.show();

                Button positiveButton = alertDialog.getButton(DialogInterface.BUTTON_POSITIVE);
                positiveButton.setTextColor(ContextCompat.getColor(mContext, R.color.colorPrimary));


                Button negativeButton = alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE);
                negativeButton.setTextColor(ContextCompat.getColor(mContext, R.color.colorPrimary));

                break;

        }
    }

    @Override
    public void onResume() {
        super.onResume();
        initNavigationView();
    }

    @Override
    public void onResponse(String tag, String response) {
        Gson gson = GsonFactory.getInstance();
        Profile profile = gson.fromJson(response, Profile.class);


        ProfileData profileData = profile.getProfileData();

        SharedPrefUtil sharedPrefUtil = SharedPrefFactory.getProfileSharedPreference(mContext);
        sharedPrefUtil.putString(BaseSharedPref.FIRST_NAME_KEY, profileData.getFirstName());
        sharedPrefUtil.putString(BaseSharedPref.LAST_NAME_KEY, profileData.getLastName());
        sharedPrefUtil.putString(BaseSharedPref.ADDRESS_KEY, profileData.getAddress());
        sharedPrefUtil.putString(BaseSharedPref.GENDER_KEY, profileData.getGender());
        sharedPrefUtil.putString(BaseSharedPref.EMAIL_ID_KEY, profileData.getEmailId());
        sharedPrefUtil.putString(BaseSharedPref.MOBILE_NUMBER_KEY, profileData.getMobileNo());
        sharedPrefUtil.putString(BaseSharedPref.MIDDLE_NAME_KEY, profileData.getMiddleName());

        fillCallDetails();


    }

    private void fillCallDetails() {
        SharedPrefUtil sharedPref = SharedPrefFactory.getProfileSharedPreference(mContext);
        String firstName = sharedPref.getString(BaseSharedPref.FIRST_NAME_KEY, "unknown");
        String lastName = sharedPref.getString(BaseSharedPref.LAST_NAME_KEY, "unknown");
        String name = firstName + " " + lastName;

        String mobileNo = sharedPref.getString(BaseSharedPref.MOBILE_NUMBER_KEY, "unknown");
        String email = sharedPref.getString(BaseSharedPref.EMAIL_ID_KEY, "unknown");
        String address = sharedPref.getString(BaseSharedPref.ADDRESS_KEY, "unknown");
        String gender = sharedPref.getString(BaseSharedPref.GENDER_KEY, "unknown");
        String Header="BILLPOWER is solutions enterprise with a data rich Analytical System";
        String Body1 ="To promote & grow Retailer & Distributor Business, Companies Brands and Products penetration, into un-serviced / less serviced outlets.";
        String Body2 ="Electronic Link between single RETAILER and  his area multiple DISTRIBUTORS and BRANDS , in the CLOSED LOOP  pattern of FMCG INDUSTRY, on one platform.";
        String Body3 ="Retailer operated, Mobile based Sales Order Generator, ideal for Serviced / Under represented / Un-represented Retailer , within allotted geographic territory of  Distributor. ";
        String Bottom ="With  Bill Power, we aim to address the last mile gap in Retail order generating process, of FMCG industry.";
        mHeaderTxt.setText(Header);
        mBody3Txt.setText(Body3);
        mBody2Txt.setText(Body2);
        mBody1Txt.setText(Body1);
        mBottomTxt.setText(Bottom);
    }

    @Override
    public void onError(String tag, String error) {
        WidgetUtil.showErrorToast(mContext, error);
    }
}

