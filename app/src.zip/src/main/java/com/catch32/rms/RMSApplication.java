package com.catch32.rms;

import android.app.Application;

import com.catch32.rms.process.AppUserManager;

/**
 * @author Ruchi Mehta
 * @version Jul 22, 2019
 */
public class RMSApplication extends Application {

    @Override
    public void onTerminate() {
        super.onTerminate();
    }
}
