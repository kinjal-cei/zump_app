package com.catch32.rms.fragment;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.catch32.rms.R;
import com.catch32.rms.activity.OrderDetailsActivity;
import com.catch32.rms.adapter.CategoryListReportAdapter;
import com.catch32.rms.adapter.CompanyAdapter;
import com.catch32.rms.adapter.ReportAdapter;
import com.catch32.rms.adapter.SubcategoryListReportAdapter;
import com.catch32.rms.constant.AppConstant;
import com.catch32.rms.constant.BaseSharedPref;
import com.catch32.rms.dialog.SingleChoiceDialog;
import com.catch32.rms.factory.GsonFactory;
import com.catch32.rms.listener.ResponseListener;
import com.catch32.rms.model.CategoryListReport;
import com.catch32.rms.model.CategoryReportData;
import com.catch32.rms.model.Company;
import com.catch32.rms.model.Reports;
import com.catch32.rms.model.SubcategoryListReport;
import com.catch32.rms.network.PostDataToServerTask;
import com.catch32.rms.utils.IBaseMenuActivity;
import com.catch32.rms.utils.ReportsUtil;
import com.catch32.rms.utils.SharedPrefFactory;
import com.catch32.rms.utils.WidgetUtil;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


public class ProductTypeFragment extends Fragment implements ResponseListener, AdapterView.OnItemSelectedListener, AdapterView.OnItemClickListener, SingleChoiceDialog.OnItemClickListener {

    private static final String TAG = ProductTypeFragment.class.getSimpleName();
    private Context mContext;
    private CategoryListReportAdapter mCategoryListReportAdapter;
    private SubcategoryListReportAdapter mSubcategoryListReportAdapter;
    private CompanyAdapter mCompanyAdapter;
    private ReportAdapter mReportAdapter;
    private List<SubcategoryListReport> mCompanyList;
    private List<CategoryReportData> mReportList;
    private List<CategoryListReport> mProductTypeList;
    private List<Company> mSubBrandList;
    private Spinner mCompanySpinner;
    private Spinner mProductTypeSpinner;
    private Spinner mSubBrandSpinner;
    private CardView mCompanyInfoView;
    private TextView mNameTv, mTotalTv, mDescTv, mSchemeTv;
    private static final String MENU_ID = "4";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_product_type, container, false);
        init(view);
        return view;
    }

    private void init(View view) {
        mContext = getActivity();
        //////SB20200225//////////////////////////
        TextView info = view.findViewById(R.id.header_path);
        info.setText("["+SharedPrefFactory.getProfileSharedPreference(mContext).getString(BaseSharedPref.USER_CD_KEY)+"] "+"Home > Reports > Product Type Wise Items");
        //////^SB20200225//////////////////////////
        mProductTypeList = new ArrayList<>();
        mCompanyList = new ArrayList<>();
        mSubBrandList = new ArrayList<>();
        mReportList = new ArrayList<>();

        mCompanyInfoView = view.findViewById(R.id.lyt_info);
        mNameTv = mCompanyInfoView.findViewById(R.id.txt_name);
        mTotalTv = mCompanyInfoView.findViewById(R.id.txt_total);
        mDescTv = mCompanyInfoView.findViewById(R.id.txt_desc);
        mSchemeTv = mCompanyInfoView.findViewById(R.id.txt_scheme);

        mCategoryListReportAdapter = new CategoryListReportAdapter(mContext, mProductTypeList);
        mSubcategoryListReportAdapter = new SubcategoryListReportAdapter(mContext, mCompanyList);
        mCompanyAdapter = new CompanyAdapter(mContext, mSubBrandList);
        mReportAdapter = new ReportAdapter(mContext, mReportList);

        mProductTypeSpinner = view.findViewById(R.id.spinner_product_type);
        mCompanySpinner = view.findViewById(R.id.spinner_company);
        mSubBrandSpinner = view.findViewById(R.id.spinner_sub_brand);

        mProductTypeSpinner.setAdapter(mCategoryListReportAdapter);
        mCompanySpinner.setAdapter(mSubcategoryListReportAdapter);
        mSubBrandSpinner.setAdapter(mCompanyAdapter);


        ListView listView = view.findViewById(R.id.list_product_type);
        listView.setEmptyView(view.findViewById(R.id.empty_view));
        listView.setAdapter(mReportAdapter);
        listView.setOnItemClickListener(this);
        listView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        mProductTypeSpinner.setOnItemSelectedListener(this);
        mCompanySpinner.setOnItemSelectedListener(this);
        mSubBrandSpinner.setOnItemSelectedListener(this);


        showCompanyInfo(null);

        ReportsUtil.getMenuData(mContext, MENU_ID, this);

    }

    private void showCompanyInfo(CategoryReportData categoryReportData) {
        if (categoryReportData == null) {
            mCompanyInfoView.setVisibility(View.GONE);
        } else {
            mCompanyInfoView.setVisibility(View.VISIBLE);

            mNameTv.setText(categoryReportData.getCM_DESC());
            mTotalTv.setText(categoryReportData.getCM_NAME());
            mSchemeTv.setText(categoryReportData.getCM_TIME());
            mDescTv.setText(categoryReportData.getCM_ROOM_NO());

            mSchemeTv.setVisibility(categoryReportData.getCM_TIME().isEmpty() ? View.GONE : View.VISIBLE);
            mDescTv.setVisibility(categoryReportData.getCM_ROOM_NO().isEmpty() ? View.GONE : View.VISIBLE);
        }
    }

    private void initNavigationView() {
        if (getActivity() instanceof IBaseMenuActivity) {
            IBaseMenuActivity baseMenuActivity = (IBaseMenuActivity) getActivity();
            baseMenuActivity.setActionbarTitle("Reports");
            baseMenuActivity.checkMenuItem(R.id.nav_home);
        }
    }


    @Override
    public void onResume() {
        super.onResume();
        initNavigationView();
    }


    @Override
    public void onResponse(String tag, String response) {
        Gson gson = GsonFactory.getInstance();
        Reports reports = null;
        CategoryReportData companyInfo = null;

        switch (tag) {
            case AppConstant.Actions.GET_MENU_DATA:
                mProductTypeList.clear();
                mCompanyList.clear();
                mSubBrandList.clear();

                reports = gson.fromJson(response, Reports.class);

                mProductTypeList.addAll(reports.getCategoryListReport());
                mCompanyList.addAll(reports.getSubcategoryListReport());
                mSubBrandList.addAll(reports.getCompList());

                mCategoryListReportAdapter.notifyDataSetChanged();
                mSubcategoryListReportAdapter.notifyDataSetChanged();
                mCompanyAdapter.notifyDataSetChanged();
                break;

            case AppConstant.Actions.GET_LIST_DATA_SECOND_SPINNER:
                mCompanyList.clear();
                mReportList.clear();
                mSubBrandList.clear();

                reports = gson.fromJson(response, Reports.class);

                companyInfo = reports.getCategoryReportData().remove(0);
                showCompanyInfo(companyInfo);

                mCompanyList.addAll(reports.getSubcategoryListReport());
                mSubBrandList.addAll(reports.getCompList());
                mReportList.addAll(reports.getCategoryReportData());

                mSubcategoryListReportAdapter.notifyDataSetChanged();
                mReportAdapter.notifyDataSetChanged();
                mCompanyAdapter.notifyDataSetChanged();

                mCompanySpinner.setSelection(0);
                mSubBrandSpinner.setSelection(0);
                break;

            case AppConstant.Actions.GET_LIST_DATA_THIRD_SPINNER:
                mSubBrandList.clear();
                mReportList.clear();
                reports = gson.fromJson(response, Reports.class);

                companyInfo = reports.getCategoryReportData().remove(0);
                showCompanyInfo(companyInfo);

                mSubBrandList.addAll(reports.getCompList());
                mReportList.addAll(reports.getCategoryReportData());

                mCompanyAdapter.notifyDataSetChanged();
                mReportAdapter.notifyDataSetChanged();

                mSubBrandSpinner.setSelection(0);
                break;

            case AppConstant.Actions.GET_LIST_DATA:
                mReportList.clear();
                reports = gson.fromJson(response, Reports.class);
                companyInfo = reports.getCategoryReportData().remove(0);
                showCompanyInfo(companyInfo);

             //SB20200707   Collections.sort(reports.getCategoryReportData());
                mReportList.addAll(reports.getCategoryReportData());
                mReportAdapter.notifyDataSetChanged();
                break;
        }

    }

    @Override
    public void onError(String tag, String error) {
        WidgetUtil.showErrorToast(mContext, error);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        int viewId = parent.getId();
        String selectedProductType = "0";
        String selectedCompany = "0";
        String selectedSubBrand = "0";
        CategoryListReport categoryListReport;
        SubcategoryListReport company;
        switch (viewId) {
            case R.id.spinner_product_type:
                if (position > 0) {
                    selectedProductType = mCategoryListReportAdapter.getItem(position).getCat_id();
                    ReportsUtil.getListData(mContext, AppConstant.Actions.GET_LIST_DATA_SECOND_SPINNER, MENU_ID, selectedProductType, selectedCompany, selectedSubBrand, this);

                }
                break;
            case R.id.spinner_company:
                if (position > 0) {
                    categoryListReport = (CategoryListReport) mProductTypeSpinner.getSelectedItem();
                    selectedProductType = categoryListReport.getCat_id();
                    selectedCompany = mSubcategoryListReportAdapter.getItem(position).getSub_cat_id();
                    ReportsUtil.getListData(mContext, AppConstant.Actions.GET_LIST_DATA_THIRD_SPINNER, MENU_ID, selectedProductType, selectedCompany, selectedSubBrand, this);
                }
                break;
            case R.id.spinner_sub_brand:
                if (position > 0) {
                    categoryListReport = (CategoryListReport) mProductTypeSpinner.getSelectedItem();
                    selectedProductType = categoryListReport.getCat_id();
                    company = (SubcategoryListReport) mCompanySpinner.getSelectedItem();
                    selectedCompany = company.getSub_cat_id();
                    selectedSubBrand = mCompanyAdapter.getItem(position).getComp_id();

                    ReportsUtil.getListData(mContext, AppConstant.Actions.GET_LIST_DATA, MENU_ID, selectedProductType, selectedCompany, selectedSubBrand, this);
                }
                break;

        }


    }


    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        view.setSelected(true);
        final CategoryReportData report = mReportAdapter.getItem(position);
        String details = report.getOFFER();
        String[] values = details.split(":");
        String title0 = "MOQ : " + values[0];
        String title1 = "Scheme : " + values[1];
        String title2 = "Scheme : " + values[2];

        Map<String, String> titleMap = new LinkedHashMap<>();
        titleMap.put(title0, values[0]);
        titleMap.put(title1, values[1]);
        titleMap.put(title2, values[2]);


        SingleChoiceDialog newFragment = new SingleChoiceDialog();
        Bundle bundle = new Bundle();
        bundle.putString(SingleChoiceDialog.TITLE, "Add (MOQ/Scheme) to Draft");
        bundle.putString(SingleChoiceDialog.TAG, TAG);
        newFragment.setArguments(bundle);
        newFragment.setItems(titleMap);
        newFragment.setReport(report);
        newFragment.setOnItemClickListener(this);
        newFragment.show(getChildFragmentManager(), "SingleChoice");
    }

    @Override
    public void OnItemClick(List<String> item, String tag, CategoryReportData report) {
        if (!item.isEmpty()) {
            String value = item.get(0);

            if (value.contains("+"))
                value = value.substring(0, value.indexOf("+"));

            Intent intent = new Intent(mContext, OrderDetailsActivity.class);
            intent.putExtra("complaint_number", report.getCM_NO());
            intent.putExtra("screen", "Product Type Report");
            intent.putExtra("position", value);
            mContext.startActivity(intent);
        }
    }
}

