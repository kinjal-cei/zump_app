package com.catch32.rms.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.catch32.rms.R;
import com.catch32.rms.constant.AppConstant;
import com.catch32.rms.constant.BaseSharedPref;
import com.catch32.rms.process.AppUserManager;
import com.catch32.rms.utils.SharedPrefFactory;
import com.catch32.rms.utils.SharedPrefUtil;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        AppUserManager.resetAppInfo(this);
        new Handler().
                postDelayed(new Runnable() {

                    @Override
                    public void run() {
                        Intent i = new Intent(SplashActivity.this, SignInActivity.class);
                        startActivity(i);
                        finish();
                    }
                }, AppConstant.SPLASH_DELAY);
    }
}
