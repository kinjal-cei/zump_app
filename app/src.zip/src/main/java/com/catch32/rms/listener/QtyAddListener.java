package com.catch32.rms.listener;

/**
 * @author Ruchi Mehta
 * @version Oct 22, 2019
 */
public interface QtyAddListener {
    void onQtyAdded(int qty);
}
