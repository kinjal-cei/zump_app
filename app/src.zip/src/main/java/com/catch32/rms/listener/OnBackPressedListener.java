package com.catch32.rms.listener;

/**
 * @author Ruchi Mehta
 * @version Dec 02, 2019
 */
public interface OnBackPressedListener {

    boolean onBackPressed();
}
